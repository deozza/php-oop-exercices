<?php

namespace App;

class Multiplier {

    public int $maxMultiplier;
    public int $maxTable;

    public function setDataFromArray(array $input): void {
        if(count($input) !== 2) {
            throw new \Exception('Invalid input format');
        }

        if($this->checkDataAreNumbers($input) === false){
            throw new \Exception('You can only type numbers');
        }

        $this->maxMultiplier = $input[0];
        $this->maxTable = $input[1];
        
    }
    
    public function checkDataAreNumbers(array $input): bool {
        for($i = 0; $i < count($input); $i++) {
            if(ctype_digit($input[$i]) === false) {
                return false;
            }
        }

        return true;
    }

    public function buildMultiplicationLine(int $line): string {
        $lineContent = "";
        for($multiplier = 1; $multiplier <= $this->maxMultiplier; $multiplier++){
            $lineContent .= $line * $multiplier . " ";
        }

        $lineContent .= "\n";

        return $lineContent;
    }

    public function buildMultiplicationMessage(): string {
        $content = "";

        for($line = 1; $line <= $this->maxTable; $line++) {
            $content .= $this->buildMultiplicationLine($line, $this->maxMultiplier);
        }

        return $content;
    }
}
