<?php

namespace App;

class MessageDisplayer {
    public function use(string $message): void {
        echo $message . PHP_EOL;
    }
}
