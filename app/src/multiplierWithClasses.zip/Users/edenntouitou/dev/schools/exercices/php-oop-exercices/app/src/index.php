<?php

use App\CsvFileReader;
use App\MessageDisplayer;
use App\Multiplier;

require_once __DIR__ . '/../vendor/autoload.php';
/*
With a CSV file in this format :
5,7
*/

try {

    $csvFileReader = new CsvFileReader();
    $csvFileReader->openNewFileHandler(__DIR__ . '/data.csv');
    $row = $csvFileReader->getNextCsvLineFromCurrentFileHandler();
    $csvFileReader->closeCurrentFileHandler();

    $messageDisplayer = new MessageDisplayer();

    $multiplier = new Multiplier();
    $multiplier->setDataFromArray($row);
    $content = $multiplier->buildMultiplicationMessage();

    $messageDisplayer->use($content);
    
} catch(\Exception $e) {
    $messageDisplayer->use($e->getMessage());
}

?>
