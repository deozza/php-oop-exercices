<?php

namespace App;

class CsvFileReader {
    private $fileHandler;

    public function openNewFileHandler(string $filepath) {
        $this->fileHandler = fopen($filepath, 'r');
    }

    public function closeCurrentFileHandler(): void {
        fclose($this->fileHandler);
        $this->fileHandler = null;
    }

    public function getNextCsvLineFromCurrentFileHandler(): array | null {
        return fgetcsv($this->fileHandler, 1000, ',', '"', '\\');
    }
}
